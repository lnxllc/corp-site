LnX合同会社 広告運用代行LP（/ad-lp/）

【設置方法】corp-site に対して、以下の3つを配置してください。
  1. ad-lp/index.html   … 上書き
  2. ad-lp/style.css    … 上書き
  3. ad-lp/img/*.webp   … 6枚（hero / hero-sp / reason-1〜3 / case-matching）

assets/ と cases/ 配下は既存サイトのものをそのまま使うので、差し替え不要です
（このzipには動作確認用の写しを同梱しています）。

【画像形式】このLPが読み込む画像はすべて WebP です。
  ad-lp/img/ に残っている result1.png / result2.png は旧LPの残骸で、
  このページからは参照していません。削除して構いません。

【同梱ファイル】
  ad-lp/index.html    ... 本体（設置する）
  ad-lp/style.css     ... LP固有CSS（設置する）
  ad-lp/img/          ... 生成画像6枚（設置する）
  ad-lp/images.json   ... 画像生成プロンプト（作り直す用。設置不要）
  ad-lp/REPORT.md     ... 仮決めした点・要確認・チェック結果・変更履歴
  ad-lp/wireframe.md  ... 構成とコピー全文・画像指示（修正時はこちらを正とする）
  ad-lp/brief.md      ... 与件の正規化メモ
  assets/ cases/      ... 参照用の既存アセット（設置不要）

※ 共通CSS（assets/css/styles.css）は一切変更していません。
